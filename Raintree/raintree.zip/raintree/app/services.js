/*requiring node modules starts */

var bodyParser = require('body-parser');

var method = routes.prototype;
function routes(app, connection, sessionInfo) {

    var file_path = "";
    app.use(bodyParser.urlencoded({
        extended: true
    }));
    app.use(bodyParser.json());

    /*
     post to handle Login request
     */
    app.post('/login', function (req, res) {


        sessionInfo = req.session;

        var userName = req.body.userName;
        var password = req.body.password;
        var type = req.body.type;

        var data = {
            query: "select userid, user_type_id, name, dob, email, passwords, mobileno, isactive, creation_date, update_date from registration where email = '" + userName + "' and passwords='" + password + "' and user_type_id = " + type + " and isactive = 1",
            connection: connection
        }

        /*
         Calling query_runner to run  SQL Query
         */
        query_runner(data, function (result) {
            var uid = "", name = "", email = "", dob = "", user_type_id = "", mobileno = "";

            result.forEach(function (element, index, array) {
                uid = element.userid;
                name = element.name;
                email = element.email;
                dob = element.dob;
                user_type_id = element.user_type_id;
                mobileno = element.mobileno;
            });

            if (result.length > 0) {
                //setting session
                sessionInfo.uid = uid;
                sessionInfo.name = name;
                result_send = {
                    is_logged: true,
                    id: uid,
                    name: name,
                    email: email,
                    dob: dob,
                    user_type_id: user_type_id,
                    mobileno: mobileno,
                    msg: "OK"
                };
            } else {
                result_send = {
                    is_logged: false,
                    id: null,
                    msg: "BAD"
                };
            }
            /*
             Sending response to client
             */
            res.write(JSON.stringify(result_send));
            res.end();
        });
    });

    /*
     post to handle manage Users request
     */
    app.post('/manageUser', function (req, res) {


        sessionInfo = req.session;
        var id = 0;
        if ('id' in req.body) {
            id = req.body.id;
        }
        var name = req.body.name;
        var email = req.body.email;
        var password = req.body.password;
        var mobileno = req.body.mobileno;
        var dob = req.body.dob;
        var type = req.body.type;
        var query = "";
        if (id != 0) {

            //delete : mark isactive 0
            if ('mark' in req.body && req.body.mark == 'delete') {
                query = "update registration set isactive  = 0, update_date = CURRENT_TIMESTAMP  where userid = " + id;
            } else {
                query = "update registration set user_type_id = " + type + ", name = '" + name + "' "
                    + ", dob = STR_TO_DATE('" + dob + "', '%d-%m-%Y'), email = '" + email + "', "
                    + " passwords = '" + password + "', mobileno = '" + mobileno + "', isactive  = 1, update_date = CURRENT_TIMESTAMP "
                    + " where userid = " + id;
            }
        } else {
            query = "insert into registration(user_type_id, name, dob, email, passwords, mobileno, isactive, creation_date) "
                + " values(" + type + ", '" + name + "', STR_TO_DATE('" + dob + "', '%d-%m-%Y'), '" + email + "', '" + password + "', '" + mobileno + "', 1, CURRENT_TIMESTAMP) ";
        }
        var data = {
            query: query,
            connection: connection
        }

        /*
         Calling query_runner to run  SQL Query
         */
        query_runner(data, function (result) {
            if (result) {
                result_send = {
                    is_inserted: true,
                    id: null,
                    msg: "Employee has been " + ((id != 0) ? "updated" : "added") + " Successfully."
                };
            } else {
                result_send = {
                    is_inserted: false,
                    id: null,
                    msg: "Employee has not been  " + ((id != 0) ? "updated" : "added") + " . Please try again."
                };
            }
            /*
             Sending response to client
             */
            res.write(JSON.stringify(result_send));
            res.end();
        });
    });

    /*
     post to hanlde gell employee data
     */
    app.post('/getEmpData', function (req, res) {
        sessionInfo = req.session;
        var query = "select user_type_name, r.user_type_id as EmpType, name, email, mobileno, passwords as password, date_format(dob, '%d-%m-%Y') as dob, isactive, if(isactive = 1, 'Active', 'De-active') status, userid as id "
            + " from registration r "
            + " inner join user_type ut on ut.user_type_id = r.user_type_id order by user_type_name, name ";


        var data = {
            query: query,
            connection: connection
        }
        /*
         Calling query_runner to run  SQL Query
         */
        query_runner(data, function (result) {
            if (result.length > 0) {

                result_send = {
                    is_data: true,
                    records: result,
                    msg: "OK"
                };
            } else {
                result_send = {
                    is_data: false,
                    records: result,
                    msg: "BAD"
                };
            }
            /*
             Sending response to client
             */
            res.write(JSON.stringify(result_send));
            res.end();
        });
    });

    /*
     get task data
     */
    app.post('/getTaskData', function (req, res) {
        sessionInfo = req.session;
        var query = "select taskid as id, task_name, task_description, assign_to, r.name as assign_to_name, p.name as posted_by_name, posted_by, posted_date, assignment_date, iscompleted, if(iscompleted = 1, 'Completed', 'Pending') status, completion_date "
            + " from tasks t "
            + " left join registration r on r.userid = t.assign_to "
            + " left join registration p on p.userid = t.posted_by";


        var data = {
            query: query,
            connection: connection
        }
        /*
         Calling query_runner to run  SQL Query
         */
        query_runner(data, function (result) {
            if (result.length > 0) {

                result_send = {
                    is_data: true,
                    records: result,
                    msg: "OK"
                };
            } else {
                result_send = {
                    is_data: false,
                    records: result,
                    msg: "BAD"
                };
            }
            /*
             Sending response to client
             */
            res.write(JSON.stringify(result_send));
            res.end();
        });
    });

    /*
     post to handle manage Users request
     */
    app.post('/manageTask', function (req, res) {


        sessionInfo = req.session;
        var id = 0;
        if ('id' in req.body) {
            id = req.body.id;
        }
        var task_name = req.body.task_name;
        var task_description = req.body.task_description;
        var assign_to = req.body.assign_to;
        var posted_by = req.body.posted_by;

        var query = "";
        if (id != 0) {

            //delete : mark isactive 0
            if ('mark' in req.body && req.body.mark == 'delete') {
                query = "update tasks set iscompleted  = 1, assign_to = null, assignment_date = null, completion_date = CURRENT_TIMESTAMP  where taskid = " + id;
            } else {
                query = "update tasks set task_name = '" + task_name + "', task_description = '" + task_description + "' "
                    + ", assign_to = '" + assign_to + "', posted_by = '" + posted_by + "', iscompleted = 0"
                    + " where taskid = " + id;
            }
        } else {
            query = "insert into tasks (task_name, task_description, assign_to, posted_by, posted_date, assignment_date) "
                + " values('" + task_name + "', '" + task_description + "', '" + assign_to + "', '" + posted_by + "', CURRENT_TIMESTAMP, CURRENT_TIMESTAMP) ";
        }
        var data = {
            query: query,
            connection: connection
        }

        /*
         Calling query_runner to run  SQL Query
         */
        query_runner(data, function (result) {
            if (result) {
                result_send = {
                    is_inserted: true,
                    id: null,
                    msg: "Task has been " + ((id != 0) ? "updated" : "added") + " Successfully."
                };
            } else {
                result_send = {
                    is_inserted: false,
                    id: null,
                    msg: "Task has not been  " + ((id != 0) ? "updated" : "added") + " . Please try again."
                };
            }
            /*
             Sending response to client
             */
            res.write(JSON.stringify(result_send));
            res.end();
        });
    });

    /*
     post to hanlde gell employee data
     */
    app.post('/getActiveEmployee', function (req, res) {
        sessionInfo = req.session;
        var query = "select userid as id, name from registration where isactive = 1 and user_type_id = 2";

        var data = {
            query: query,
            connection: connection
        }
        /*
         Calling query_runner to run  SQL Query
         */
        query_runner(data, function (result) {
            if (result.length > 0) {

                result_send = {
                    is_data: true,
                    records: result,
                    msg: "OK"
                };
            } else {
                result_send = {
                    is_data: false,
                    records: result,
                    msg: "BAD"
                };
            }
            /*
             Sending response to client
             */
            res.write(JSON.stringify(result_send));
            res.end();
        });
    });

    /*
     post to hanlde gell employee data
     */
    app.post('/getAssignTask', function (req, res) {
        sessionInfo = req.session;
        var query = "select taskid as id, task_name, task_description, assign_to, r.name as assign_to_name, p.name as posted_by_name, posted_by, posted_date, date_format(assignment_date, '%d-%m-%Y') assignment_date, iscompleted, if(iscompleted = 1, 'Completed', 'Pending') status, completion_date "
            + " from tasks t "
            + " inner join registration r on r.userid = t.assign_to "
            + " inner join registration p on p.userid = t.posted_by"
            + " where t.assign_to = " + req.body.id;

        var data = {
            query: query,
            connection: connection
        }
        /*
         Calling query_runner to run  SQL Query
         */
        query_runner(data, function (result) {
            if (result.length > 0) {

                result_send = {
                    is_data: true,
                    records: result,
                    msg: "OK"
                };
            } else {
                result_send = {
                    is_data: false,
                    records: result,
                    msg: "BAD"
                };
            }
            /*
             Sending response to client
             */
            res.write(JSON.stringify(result_send));
            res.end();
        });
    });

    /*
     post to handle manage Users request
     */
    app.post('/empUpdTask', function (req, res) {
        sessionInfo = req.session;
        var id = req.body.id;
        var query = "update tasks set iscompleted  = 1, completion_date = CURRENT_TIMESTAMP  where taskid = " + id;
        var data = {
            query: query,
            connection: connection
        }

        /*
         Calling query_runner to run  SQL Query
         */
        query_runner(data, function (result) {
            if (result) {
                result_send = {
                    is_inserted: true,
                    id: null,
                    msg: "Employee has been " + ((id != 0) ? "updated" : "added") + " Successfully."
                };
            } else {
                result_send = {
                    is_inserted: false,
                    id: null,
                    msg: "Employee has not been  " + ((id != 0) ? "updated" : "added") + " . Please try again."
                };
            }
            /*
             Sending response to client
             */
            res.write(JSON.stringify(result_send));
            res.end();
        });
    });

    /*
     post to handle manage Post request
     */
    app.post('/managePost', function (req, res) {


        sessionInfo = req.session;
        var id = 0;
        if ('id' in req.body) {
            id = req.body.id;
        }
        var post_name = req.body.post_name;
        var post_description = req.body.post_description;
        var last_show_date = req.body.last_show_date;
        var isoffer = req.body.isoffer;
        var promocode = (req.body.promocode == null ? null : "'" + req.body.promocode + "'");
        var dis_percentage = req.body.dis_percentage;
        var image_path = req.body.image_path;
        var posted_by = req.body.posted_by;

        var query = "";
        if (id != 0) {

            //delete : mark isactive 0
            if ('mark' in req.body && req.body.mark == 'delete') {
                query = "update posts set isactive  = 0 where postid = " + id;
            } else {
                query = "update posts set post_name = '" + post_name + "', post_description = '" + post_description + "' "
                    + ", last_show_date = STR_TO_DATE('" + last_show_date + "', '%d-%m-%Y'), posted_by = '" + posted_by + "', isoffer = " + isoffer + " "
                    + ", promocode = " + promocode + ", dis_percentage = " + dis_percentage + ", isactive = 1 "
                    + " where postid = " + id;
            }
        } else {
            query = "insert into posts(post_name, post_description, post_date, last_show_date, posted_by, isoffer, promocode, dis_percentage, image_path)"
                + " values('" + post_name + "', '" + post_description + "', CURRENT_TIMESTAMP, STR_TO_DATE('" + last_show_date + "', '%d-%m-%Y'), '" + posted_by + "', " + isoffer + ", " + promocode + ", " + dis_percentage + ", '" + image_path + "') ";
        }
        var data = {
            query: query,
            connection: connection
        }

        /*
         Calling query_runner to run  SQL Query
         */
        query_runner(data, function (result) {
            if (result) {
                result_send = {
                    is_inserted: true,
                    id: result.insertId,
                    msg: "Post has been " + ((id != 0) ? "updated" : "added") + " Successfully."
                };
            } else {
                result_send = {
                    is_inserted: false,
                    id: null,
                    msg: "Post has not been  " + ((id != 0) ? "updated" : "added") + " . Please try again."
                };
            }
            /*
             Sending response to client
             */
            res.write(JSON.stringify(result_send));
            res.end();
        });
    });

    /*
     get posts data
     */
    app.post('/getPostData', function (req, res) {
        sessionInfo = req.session;
        var query = "select postid as id, post_name, post_description, date_format(post_date, '%d-%m-%Y') post_date, date_format(last_show_date, '%d-%m-%Y') last_show_date, p.isactive, if(p.isactive = 1, 'Active', 'De-active') status, posted_by, r.name posted_by_name, isoffer, promocode, dis_percentage, image_path "
            + " from posts p "
            + " inner join registration r on p.posted_by = r.userid";

        var data = {
            query: query,
            connection: connection
        }
        /*
         Calling query_runner to run  SQL Query
         */
        query_runner(data, function (result) {
            if (result.length > 0) {

                result_send = {
                    is_data: true,
                    records: result,
                    msg: "OK"
                };
            } else {
                result_send = {
                    is_data: false,
                    records: result,
                    msg: "BAD"
                };
            }
            /*
             Sending response to client
             */
            res.write(JSON.stringify(result_send));
            res.end();
        });
    });

    /*
     post to handle manage Users request
     */
    app.post('/uploadFile', function (req, res) {
        var file = req.files.file;
        var id = req.body.id;
        var image_path = file.path.substr(file.path.lastIndexOf("\\") + 1, file.path.length);
        var query = "update posts set image_path = '" + image_path + "' where postid = " + id;
        var data = {
            query: query,
            connection: connection
        }

        /*
         Calling query_runner to run  SQL Query
         */
        query_runner(data, function (result) {
            if (result) {
                result_send = {
                    is_inserted: true,
                    id: result.insertId,
                    msg: "success"
                };
            } else {
                result_send = {
                    is_inserted: false,
                    id: null,
                    msg: "fail"
                };
            }
            /*
             Sending response to client
             */
            res.write(JSON.stringify(result_send));
            res.end();
        });

        //console.log(file);
        //console.log(file.path);
    });

    /*
     get posts data
     */
    app.post('/getLatestPostData', function (req, res) {
        sessionInfo = req.session;
        var query = "select postid as id, post_name, post_description, date_format(last_show_date, '%d-%m-%Y') last_show_date, isactive, posted_by, isoffer, promocode, dis_percentage, image_path "
            + " from posts p "
            + " where isactive = 1"
            + " order by post_date desc limit 3";

        var data = {
            query: query,
            connection: connection
        }
        /*
         Calling query_runner to run  SQL Query
         */
        query_runner(data, function (result) {
            if (result.length > 0) {

                result_send = {
                    is_data: true,
                    records: result,
                    msg: "OK"
                };
            } else {
                result_send = {
                    is_data: false,
                    records: result,
                    msg: "BAD"
                };
            }
            /*
             Sending response to client
             */
            res.write(JSON.stringify(result_send));
            res.end();
        });
    });

    /*
     post to handle User registration request
     */
    app.post('/makeRegistration', function (req, res) {


        sessionInfo = req.session;
        var name = req.body.name;
        var email = req.body.email;
        var password = req.body.password;
        var mobileno = req.body.mobileno;
        var dob = req.body.dob;
        var type = 3;
        var query = "insert into registration(user_type_id, name, dob, email, passwords, mobileno, isactive, creation_date) "
            + " values(" + type + ", '" + name + "', STR_TO_DATE('" + dob + "', '%d-%m-%Y'), '" + email + "', '" + password + "', '" + mobileno + "', 1, CURRENT_TIMESTAMP) ";
        var data = {
            query: query,
            connection: connection
        }

        /*
         Calling query_runner to run  SQL Query
         */
        query_runner(data, function (result) {
            if (result) {
                result_send = {
                    is_inserted: true,
                    id: null,
                    msg: "You have been registered Successfully."
                };
            } else {
                result_send = {
                    is_inserted: false,
                    id: null,
                    msg: "You have not been registered. Please try again."
                };
            }
            /*
             Sending response to client
             */
            res.write(JSON.stringify(result_send));
            res.end();
        });
    });

    /*
     get floor data
     */
    app.post('/getFloor', function (req, res) {
        sessionInfo = req.session;
        var query = "select floor as id, floor_name as name from floor";
        var data = {
            query: query,
            connection: connection
        }
        /*
         Calling query_runner to run  SQL Query
         */
        query_runner(data, function (result) {
            if (result.length > 0) {
                result_send = {
                    is_data: true,
                    records: result,
                    msg: "OK"
                };
            } else {
                result_send = {
                    is_data: false,
                    records: result,
                    msg: "BAD"
                };
            }
            /*
             Sending response to client
             */
            res.write(JSON.stringify(result_send));
            res.end();
        });
    });

    /*
     get posts data
     */
    app.post('/getRoom', function (req, res) {
        sessionInfo = req.session;
        var query = "select roomid as id, floor, roomno, isac, amount from rooms where floor = " + req.body.id;

        var data = {
            query: query,
            connection: connection
        }
        /*
         Calling query_runner to run  SQL Query
         */
        query_runner(data, function (result) {
            if (result.length > 0) {

                result_send = {
                    is_data: true,
                    records: result,
                    msg: "OK"
                };
            } else {
                result_send = {
                    is_data: false,
                    records: result,
                    msg: "BAD"
                };
            }
            /*
             Sending response to client
             */
            res.write(JSON.stringify(result_send));
            res.end();
        });
    });

    /*
     post to handle booking request
     */
    app.post('/booking', function (req, res) {


            sessionInfo = req.session;
            var id = 0;
            if ('id' in req.body) {
                id = req.body.id;
            }
            var room = req.body.room;
            var booked_by = req.body.booked_by;
            var time_from = req.body.date_from;
            var time_to = req.body.date_to;
            var amount = req.body.amount;
            var query = "";
            if (id != 0) {
                //delete : mark isactive 0
                if ('mark' in req.body && req.body.mark == 'delete') {
                    query = "update booking set iscanceled  = 1 where bookingid = " + id;
                }
            } else {
                query = "insert into booking(roomid, booked_by, booking_date, time_from, time_to, creation_date, amount) "
                    + " values(" + room + ", '" + booked_by + "', CURRENT_TIMESTAMP, STR_TO_DATE('" + time_from + "', '%d-%m-%Y %H:%i:%s'), STR_TO_DATE('" + time_to + "', '%d-%m-%Y %H:%i:%s'), CURRENT_TIMESTAMP, '" + amount + "') ";
            }
            var data = {
                query: query,
                connection: connection
            }

            /*
             Calling query_runner to run  SQL Query
             */
            query_runner(data, function (result) {
                if (result) {
                    result_send = {
                        is_inserted: true,
                        id: null,
                        msg: "Your order has been " + ((id != 0) ? "canceled" : "placed") + " Successfully."
                    };
                } else {
                    result_send = {
                        is_inserted: false,
                        id: null,
                        msg: "Your order has not been been " + ((id != 0) ? "canceled" : "placed") + ". Please try again."
                    };
                }
                /*
                 Sending response to client
                 */
                res.write(JSON.stringify(result_send));
                res.end();
            });
        }
    );

    /*
     get posts data
     */
    app.post('/getOrderHistory', function (req, res) {
        sessionInfo = req.session;
        var query = "select bookingid as id, b.roomid, booked_by, date_format(time_from, '%d-%m-%Y %h:%i:%s') time_from, date_format(time_to, '%d-%m-%Y %h:%i:%s') time_to,  date_format(creation_date, '%d-%m-%Y') creation_date, iscompleted, iscanceled, b.amount, roomno, floor_name, if(iscanceled = 1, 'Canceled', 'Active') status "
            + " from booking b "
            + " inner join rooms r on r.roomid = b.roomid "
            + " inner join floor f on f.floor = r.floor "
            + " where b.booked_by = " + req.body.id

        var data = {
            query: query,
            connection: connection
        }
        /*
         Calling query_runner to run  SQL Query
         */
        query_runner(data, function (result) {
            if (result.length > 0) {

                result_send = {
                    is_data: true,
                    records: result,
                    msg: "OK"
                };
            } else {
                result_send = {
                    is_data: false,
                    records: result,
                    msg: "BAD"
                };
            }
            /*
             Sending response to client
             */
            res.write(JSON.stringify(result_send));
            res.end();
        });
    });
}

method.getroutes = function () {
    return this;
}

module.exports = routes;


/*
 Making query_runner function to Run mysl queries
 */
var query_runner = function (data, callback) {
    var db_conncetion = data.connection;
    var query = data.query;
    var insert_data = data.insert_data;
    db_conncetion.getConnection(function (err, con) {
        if (err) {
            con.release();
        } else {
            db_conncetion.query(String(query), insert_data, function (err, rows) {
                con.release();
                if (!err) {
                    callback(rows);
                } else {
                    console.log(err);
                    console.log("Query failed");
                }
            });
        }
    });
}