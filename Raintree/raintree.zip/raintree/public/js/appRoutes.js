angular.module('appRoutes', []).config(['$routeProvider', '$locationProvider', function ($routeProvider, $locationProvider) {
    $routeProvider.when('/login', {
        templateUrl: 'views/login.html',
        controller: 'LoginCtrl'
    }).when('/home', {
        templateUrl: 'views/home.html',
        controller: 'mHomeCtrl'
    }).when('/mEmp', {
        templateUrl: 'views/manager/mEmp.html',
        controller: 'mEmpCtrl'
    }).when('/addEmp', {
        templateUrl: 'views/manager/addEmp.html',
        controller: 'mEmpCtrl'
    }).when('/mTask', {
        templateUrl: 'views/manager/mTask.html',
        controller: 'mTaskCtrl'
    }).when('/mPost', {
        templateUrl: 'views/manager/mPost.html',
        controller: 'mPostCtrl'
    }).when('/logout', {
        templateUrl: 'views/login.html',
        controller: 'logoutCtrl'
    }).when('/eView', {
        templateUrl: 'views/employee/eView.html',
        controller: 'employeeCtrl'
    }).otherwise({
        redirectTo: '/home'
    });

    $locationProvider.html5Mode({
        enabled: true,
        requireBase: false
    });

}]).run(function ($rootScope, $location, $templateCache) {

    //$rootScope.$on("$routeChangeStart", function (event, next, current) {
    //    //console.log($rootScope.loggedInUser);
    //});
})
;