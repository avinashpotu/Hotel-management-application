angular.module('mTaskService', []).factory('TaskService', function ($http, $q) {
    var records = [];
    return {
        get: function () {
            return $http.post('/getTaskData');
        },
        set: function (data) {
            records = [];
            for (i in data) {
                var userObj = data[i];
                userObj.availableOptions = [];
                records.push(userObj);
            }
        },
        add: function (data) {
            return $http.post('/manageTask', data);
        },
        list: function () {
            return records;
        },
        edit: function (id) {
            for (i in records) {
                if (records[i].id == id) {
                    return records[i];
                }
            }
        },
        delete: function (id) {
            var data = {id: id, mark: 'delete'}
            return $http.post('/manageTask', data);
        },
        getEmployee: function () {
            return $http.post('/getActiveEmployee');
        }
    }
});
