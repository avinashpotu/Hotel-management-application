angular.module('mEmpService', []).factory('EmpService', function ($http, $q) {
    //records array to hold list of all records
    var records = [];
    return {
        get: function () {
            return $http.post('/getEmpData');
        },
        set: function (data) {
            records = [];
            for (i in data) {
                var userObj = data[i];
                userObj.availableOptions = [];
                userObj.EmpType1 = userObj.EmpType;
                userObj.EmpType = {id: userObj.EmpType, name: userObj.user_type_name};
                userObj.mobileno = parseFloat(userObj.mobileno);
                records.push(userObj);
            }
        },
        add: function (data) {
            return $http.post('/manageUser', data);
        },
        list: function () {
            return records;
        },
        edit: function (id) {
            for (i in records) {
                if (records[i].id == id) {
                    return records[i];
                }
            }
        },
        delete: function (id) {
            var data = {id: id, mark: 'delete'}
            return $http.post('/manageUser', data);
        }
    }
});
