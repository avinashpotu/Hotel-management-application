angular.module('employeeService', []).factory('EmployeeService', function ($http, $q) {
    return {
        get: function (id) {
            var data = {id: id};
            return $http.post('/getAssignTask', data);
        },
        edit: function (id) {
            var data = {id: id}
            return $http.post('/empUpdTask', data);
        }
    }
});
