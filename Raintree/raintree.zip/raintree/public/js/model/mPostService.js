angular.module('mPostService', []).factory('PostService', function ($http, $q) {
    //records array to hold list of all records
    var records = [];
    return {
        get: function () {
            return $http.post('/getPostData');
        },
        set: function (data) {
            records = [];
            for (i in data) {
                var Obj = data[i];
                Obj.promocode = parseFloat(Obj.promocode);
                Obj.dis_percentage = parseFloat(Obj.dis_percentage);
                Obj.isoffer = (Obj.isoffer == 1 ? true : false);
                Obj.image_path = null;
                records.push(Obj);
            }
        },
        add: function (data) {
            return $http.post('/managePost', data);
        },
        list: function () {
            return records;
        },
        edit: function (id) {
            for (i in records) {
                if (records[i].id == id) {
                    return records[i];
                }
            }
        },
        delete: function (id) {
            var data = {id: id, mark: 'delete'}
            return $http.post('/managePost', data);
        }
    }
});
