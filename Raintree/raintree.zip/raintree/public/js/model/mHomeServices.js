angular.module('mHomeServices', []).factory('HomeServices', function ($http, $q) {
    return {
        get: function () {
            var data = {};
            return $http.post('/getLatestPostData', data);
        },
        add: function (data) {
            return $http.post('/makeRegistration', data);
        },
        login: function (data) {
            return $http.post('/login', data);
        },
        getRoom: function (data) {
            return $http.post('/getRoom', data);
        },
        getFloor: function (data) {
            return $http.post('/getFloor', data);
        },
        booking: function (data) {
            return $http.post('/booking', data);
        },
        getOrderHistory: function (data) {
            return $http.post('/getOrderHistory', data);
        },
        delete: function (id) {
            var data = {id: id, mark: 'delete'}
            return $http.post('/booking', data);
        }
    }
});
