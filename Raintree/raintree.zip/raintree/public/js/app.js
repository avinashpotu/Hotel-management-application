angular.module('rainTreeApp', ['ngRoute', 'appRoutes', 'loginCtrl', 'mHomeCtrl',
    'mEmpCtrl', 'mTaskCtrl', 'mPostCtrl', 'logoutCtrl', 'employeeCtrl',
    'mEmpService', 'mTaskService', 'mPostService', 'employeeService', 'mHomeServices',
    'pickerModule', 'validFileModule', 'ngFileUpload', 'pickadate']);
