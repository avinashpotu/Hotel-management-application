jQuery(function ($) {
    'use strict',

        //Countdown js
        $("#countdown").countdown({
                date: "10 july 2017 12:00:00",
                format: "on"
            },

            function () {
                // callback function
            });


    //Scroll Menu

    function menuToggle() {
        var windowWidth = $(window).width();

        if (windowWidth > 767) {
            $(window).on('scroll', function () {
                if ($(window).scrollTop() > 405) {
                    $('.main-nav').addClass('fixed-menu animated slideInDown');
                } else {
                    $('.main-nav').removeClass('fixed-menu animated slideInDown');
                }
            });
        } else {

            $('.main-nav').addClass('fixed-menu animated slideInDown');

        }
    }

    menuToggle();
    $(document).ready(function () {
        //$('#main-slider').attr('height', $(window).height() - 50);
        $('#main-slider').css('height', $(window).height());
        $('#explore').css('height', $(window).height());
    })

    // Carousel Auto Slide Off
    $('#event-carousel, #twitter-feed, #sponsor-carousel ').carousel({
        interval: false
    });


    // Contact form validation
    var form = $('.contact-form');
    form.submit(function () {
        'use strict',
            $this = $(this);
        $.post($(this).attr('action'), function (data) {
            $this.prev().text(data.message).fadeIn().delay(3000).fadeOut();
        }, 'json');
        return false;
    });

    $(window).resize(function () {
        menuToggle();
    });

    $('.main-nav ul').onePageNav({
        currentClass: 'active',
        changeHash: false,
        scrollSpeed: 900,
        scrollOffset: 0,
        scrollThreshold: 0.3,
        filter: ':not(.no-scroll)'
    });

});

$(document).ready(function () {
    var vph = $(window).height();
    $('#main-section').css('height', vph + 'px');
    $('#event').css('height', vph + 'px');
});

$("#menu-toggle").click(function (e) {
    e.preventDefault();
    $("#wrapper").toggleClass("toggled");
});


//
//$(function () {
//
//    var $formLogin = $('#login_form');
//    var $formLost = $('#lost-form');
//    var $formRegister = $('#register-form');
//    var $divForms = $('#div-forms');
//    var $modalAnimateTime = 300;
//    var $msgAnimateTime = 150;
//    var $msgShowTime = 2000;
//
//    $("#login_form").submit(function (event) {
//        var param = getFormData(document.login_form);
//
//        var createmsg = callDataValid("phpfiles/process_login.php", param);
//        if (createmsg == 'error') {
//            msgChange($('#div-login-msg'), $('#icon-login-msg'), $('#text-login-msg'), "error", "glyphicon-remove", "Please enter valid credential.");
//            event.preventDefault();
//        }
//        return true;
//    });
//
//    //$("form").submit(function () {
//    //    return false;
//    //    switch (this.id) {
//    //        case "login-form":
//    //            var $lg_username = $('#login_username').val();
//    //            var $lg_password = $('#login_password').val();
//    //            if ($lg_username == "ERROR") {
//    //                msgChange($('#div-login-msg'), $('#icon-login-msg'), $('#text-login-msg'), "error", "glyphicon-remove", "Login error");
//    //            } else {
//    //                msgChange($('#div-login-msg'), $('#icon-login-msg'), $('#text-login-msg'), "success", "glyphicon-ok", "Login OK");
//    //            }
//    //            return false;
//    //            break;
//    //        case "lost-form":
//    //            var $ls_email = $('#lost_email').val();
//    //            if ($ls_email == "ERROR") {
//    //                msgChange($('#div-lost-msg'), $('#icon-lost-msg'), $('#text-lost-msg'), "error", "glyphicon-remove", "Send error");
//    //            } else {
//    //                msgChange($('#div-lost-msg'), $('#icon-lost-msg'), $('#text-lost-msg'), "success", "glyphicon-ok", "Send OK");
//    //            }
//    //            return false;
//    //            break;
//    //        case "register-form":
//    //            var $rg_username = $('#register_username').val();
//    //            var $rg_email = $('#register_email').val();
//    //            var $rg_password = $('#register_password').val();
//    //            if ($rg_username == "ERROR") {
//    //                msgChange($('#div-register-msg'), $('#icon-register-msg'), $('#text-register-msg'), "error", "glyphicon-remove", "Register error");
//    //            } else {
//    //                msgChange($('#div-register-msg'), $('#icon-register-msg'), $('#text-register-msg'), "success", "glyphicon-ok", "Register OK");
//    //            }
//    //            return false;
//    //            break;
//    //        default:
//    //            return false;
//    //    }
//    //});
//
//    $('#login_register_btn').click(function () {
//        modalAnimate($formLogin, $formRegister)
//    });
//    $('#register_login_btn').click(function () {
//        modalAnimate($formRegister, $formLogin);
//    });
//    $('#login_lost_btn').click(function () {
//        modalAnimate($formLogin, $formLost);
//    });
//    $('#lost_login_btn').click(function () {
//        modalAnimate($formLost, $formLogin);
//    });
//    $('#lost_register_btn').click(function () {
//        modalAnimate($formLost, $formRegister);
//    });
//    $('#register_lost_btn').click(function () {
//        modalAnimate($formRegister, $formLost);
//    });
//
//    function modalAnimate($oldForm, $newForm) {
//        var $oldH = $oldForm.height();
//        var $newH = $newForm.height();
//        $divForms.css("height", $oldH);
//        $oldForm.fadeToggle($modalAnimateTime, function () {
//            $divForms.animate({height: $newH}, $modalAnimateTime, function () {
//                $newForm.fadeToggle($modalAnimateTime);
//            });
//        });
//    }
//
//    function msgFade($msgId, $msgText) {
//        $msgId.fadeOut($msgAnimateTime, function () {
//            $(this).text($msgText).fadeIn($msgAnimateTime);
//        });
//    }
//
//    function msgChange($divTag, $iconTag, $textTag, $divClass, $iconClass, $msgText) {
//        var $msgOld = $divTag.text();
//        msgFade($textTag, $msgText);
//        $divTag.addClass($divClass);
//        $iconTag.removeClass("glyphicon-chevron-right");
//        $iconTag.addClass($iconClass + " " + $divClass);
//        setTimeout(function () {
//            msgFade($textTag, $msgOld);
//            $divTag.removeClass($divClass);
//            $iconTag.addClass("glyphicon-chevron-right");
//            $iconTag.removeClass($iconClass + " " + $divClass);
//        }, $msgShowTime);
//    }
//});
