angular.module('employeeCtrl', []).controller('employeeCtrl', ['$scope', '$http', '$window', '$location', '$rootScope', 'EmployeeService', function ($scope, $http, $window, $location, $rootScope, EmployeeService) {
    $rootScope.adminpanel = true;
    $rootScope.userpanel = false;
    if ($window.localStorage.getItem('empuid') == null || $window.localStorage.getItem('empuid') == '' || $window.localStorage.getItem('empuid') == 'undefined') {
        $location.path("/login");
    } else {
        $scope.displayName = $window.localStorage.getItem('empuname');
        $scope.employeeId = $window.localStorage.getItem('empuid');
        $scope.isView = true;
        $scope.isAdd = false;
        $scope.ErrorFlag = false;
        $scope.SuccessFlag = false;

        EmployeeService.get($scope.employeeId).success(function (data) {
            $scope.allData = data.records;
        });
        $scope.edit = function (id) {
            if (confirm("Are you sure you want to complete this task?")) {
                EmployeeService.edit(id).success(function (data, status, headers, config) {
                    if (data.is_inserted) {
                        $scope.SuccessFlag = true;
                        $scope.MSG = data.msg;
                        EmployeeService.get($scope.employeeId).success(function (data) {
                            $scope.allData = data.records;
                        });
                    } else {
                        $scope.ErrorFlag = true;
                        $scope.MSG = data.msg;
                    }
                }).error(function (data, status) {
                    alert("Connection Error");
                });
            }
        }
        $scope.isCompleted = function (flag) {
            return !(flag === 1);
        }
    }
}]);
