angular.module('mPostCtrl', []).controller('mPostCtrl', ['$scope', '$http', '$window', '$location', '$rootScope', 'Upload', '$timeout', 'PostService', function ($scope, $http, $window, $location, $rootScope, Upload, $timeout, PostService) {
    $rootScope.adminpanel = true;
    $rootScope.userpanel = false;
    if ($window.localStorage.getItem('uid') == null || $window.localStorage.getItem('uid') == '' || $window.localStorage.getItem('uid') == 'undefined') {
        $location.path("/login");
    } else {
        $scope.displayName = $window.localStorage.getItem('uname');
        $scope.isView = true;
        $scope.isAdd = false;
        $scope.ErrorFlag = false;
        $scope.SuccessFlag = false;

        $scope.user = angular.copy($scope.empType);

        $scope.reloadData = function () {
            PostService.get().success(function (data) {
                $scope.allData = data.records;
                PostService.set($scope.allData);
            });
        };

        if (PostService.list().length == 0) {
            $scope.reloadData();
        } else {
            $scope.allData = PostService.list();
        }

        $scope.changeView = function (view) {
            if (view == 'add') {
                $scope.isView = false;
                $scope.isAdd = true;
            } else if (view == 'view') {
                $scope.isView = true;
                $scope.isAdd = false;
                $scope.user = angular.copy($scope.empType);
            }
        }

        /* Login operation starts*/
        $scope.add = function (file) {

            var data = {
                id: $scope.post.id,
                post_name: $scope.post.post_name,
                post_description: $scope.post.post_description,
                last_show_date: $scope.post.last_show_date,
                isoffer: ((typeof $scope.post.isoffer == 'undefined' || !$scope.post.isoffer) ? "0" : $scope.post.isoffer),
                promocode: (typeof $scope.post.promocode == 'undefined' ? null : $scope.post.promocode),
                dis_percentage: (typeof $scope.post.dis_percentage == 'undefined' ? null : $scope.post.dis_percentage),
                image_path: $scope.post.image_path,
                posted_by: $window.localStorage.getItem('uid')
            };
            PostService.add(data).success(function (data, status, headers, config) {
                if (data.is_inserted) {
                    $scope.SuccessFlag = true;
                    $scope.MSG = data.msg;
                    var id = data.id;
                    if (id == 0) {
                        id = $scope.post.id;
                    }
                    file.upload = Upload.upload({
                        url: '/uploadFile',
                        data: {id: id, file: file},
                    });

                    file.upload.then(function (response) {
                        $timeout(function () {
                            file.result = response.data;
                        });
                    }, function (response) {
                        if (response.status > 0)
                            $scope.errorMsg = response.status + ': ' + response.data;
                    }, function (evt) {
                        // Math.min is to fix IE which reports 200% sometimes
                        file.progress = Math.min(100, parseInt(100.0 * evt.loaded / evt.total));
                    });
                    $scope.post = {};
                    $scope.reloadData();
                    $scope.changeView('view');
                } else {
                    $scope.ErrorFlag = true;
                    $scope.MSG = data.msg;
                }
            }).error(function (data, status) {
                alert("Connection Error");
            });
        };

        $scope.delete = function (id) {
            if (confirm("Are you sure you want to delete this record?")) {
                PostService.delete(id).success(function (data, status, headers, config) {
                    if (data.is_inserted) {
                        $scope.SuccessFlag = true;
                        $scope.MSG = data.msg;
                        $scope.user = {};
                        $scope.user = angular.copy($scope.empType);
                        $scope.reloadData();
                        $scope.changeView('view');
                    } else {
                        $scope.ErrorFlag = true;
                        $scope.MSG = data.msg;
                    }
                }).error(function (data, status) {
                    alert("Connection Error");
                });
            }
        }

        $scope.edit = function (id) {
            $scope.post = angular.copy(PostService.edit(id));
            $scope.changeView('add');
        }

        $scope.isCompleted = function (flag) {
            return !(flag == '0');
        }
    }
}]);
