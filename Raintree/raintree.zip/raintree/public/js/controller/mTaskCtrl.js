angular.module('mTaskCtrl', []).controller('mTaskCtrl', ['$scope', '$http', '$window', '$location', '$rootScope', 'TaskService', '$rootScope', function ($scope, $http, $window, $location, $rootScope, TaskService) {
    $rootScope.adminpanel = true;
    $rootScope.userpanel = false;
    if ($window.localStorage.getItem('uid') == null || $window.localStorage.getItem('uid') == '' || $window.localStorage.getItem('uid') == 'undefined') {
        $location.path("/login");
    } else {
        $scope.displayName = $window.localStorage.getItem('uname');
        $scope.isView = true;
        $scope.isAdd = false;
        $scope.ErrorFlag = false;
        $scope.SuccessFlag = false;
        $scope.allEmpData = [];

        $scope.reloadData = function () {
            TaskService.get().success(function (data) {
                $scope.allData = data.records;
                TaskService.set($scope.allData);
            });
        };

        if (TaskService.list().length == 0) {
            $scope.reloadData();
        } else {
            $scope.allData = TaskService.list();
        }


        TaskService.getEmployee().success(function (data) {
            $scope.empRecodes = {
                availableOptions: data.records
            }
            $scope.task = angular.copy($scope.empRecodes);
        });

        $scope.changeView = function (view) {
            if (view == 'add') {
                $scope.isView = false;
                $scope.isAdd = true;
            } else if (view == 'view') {
                $scope.isView = true;
                $scope.isAdd = false;
                $scope.task = angular.copy($scope.empRecodes);
            }
        }

        /* Login operation starts*/
        $scope.add = function () {
            var data = {
                id: $scope.task.id,
                task_name: $scope.task.task_name,
                task_description: $scope.task.task_description,
                assign_to: $scope.task.assign_to.id,
                posted_by: $window.localStorage.getItem('uid')
            };
            TaskService.add(data).success(function (data, status, headers, config) {
                if (data.is_inserted) {
                    $scope.SuccessFlag = true;
                    $scope.MSG = data.msg;
                    $scope.task = {};
                    $scope.task = angular.copy($scope.empRecodes);
                    $scope.reloadData();
                    $scope.changeView('view');
                } else {
                    $scope.ErrorFlag = true;
                    $scope.MSG = data.msg;
                }
            }).error(function (data, status) {
                alert("Connection Error");
            });
        };

        $scope.delete = function (id) {
            if (confirm("Are you sure you want to delete this record?")) {
                TaskService.delete(id).success(function (data, status, headers, config) {
                    if (data.is_inserted) {
                        $scope.SuccessFlag = true;
                        $scope.MSG = data.msg;
                        $scope.task = {};
                        $scope.task = angular.copy($scope.empRecodes);
                        $scope.reloadData();
                        $scope.changeView('view');
                    } else {
                        $scope.ErrorFlag = true;
                        $scope.MSG = data.msg;
                    }
                }).error(function (data, status) {
                    alert("Connection Error");
                });
            }
        }

        $scope.edit = function (id) {
            var taskObj = angular.copy(TaskService.edit(id));
            taskObj.availableOptions = angular.copy($scope.empRecodes.availableOptions);
            taskObj.assign_to = {id: taskObj.assign_to, name: taskObj.assign_to_name};
            $scope.task = taskObj;
            console.log(taskObj);
            $scope.changeView('add');
        }
        $scope.isCompleted = function (flag) {
            return !(flag === 1);
        }
    }
}]);
