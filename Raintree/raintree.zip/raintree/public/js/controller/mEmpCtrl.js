angular.module('mEmpCtrl', []).controller('mEmpCtrl', ['$scope', '$http', '$window', '$location', '$rootScope','EmpService', function ($scope, $http, $window, $location, $rootScope, EmpService) {
    $rootScope.adminpanel = true;
    $rootScope.userpanel = false;
    if ($window.localStorage.getItem('uid') == null || $window.localStorage.getItem('uid') == '' || $window.localStorage.getItem('uid') == 'undefined') {
        $location.path("/login");
    } else {
        $scope.displayName = $window.localStorage.getItem('uname');
        $scope.isView = true;
        $scope.isAdd = false;
        $scope.ErrorFlag = false;
        $scope.SuccessFlag = false;
        $scope.empType = {
            availableOptions: [
                //{id: '', name: 'Please select Type'},
                {id: '1', name: 'Manager'},
                {id: '2', name: 'Employee'}
            ],
            //EmpType: {}
        };

        $scope.user = angular.copy($scope.empType);

        $scope.reloadData = function () {
            EmpService.get().success(function (data) {
                $scope.allData = data.records;
                EmpService.set($scope.allData);
            });
        };

        if (EmpService.list().length == 0) {
            $scope.reloadData();
        } else {
            $scope.allData = EmpService.list();
        }

        $scope.changeView = function (view) {
            if (view == 'add') {
                $scope.isView = false;
                $scope.isAdd = true;
            } else if (view == 'view') {
                $scope.isView = true;
                $scope.isAdd = false;
                $scope.user = angular.copy($scope.empType);
            }
        }

        /* Login operation starts*/
        $scope.add = function () {
            var data = {
                id: $scope.user.id,
                name: $scope.user.name,
                email: $scope.user.email,
                password: $scope.user.password,
                mobileno: $scope.user.mobileno,
                dob: $scope.user.dob,
                type: $scope.user.EmpType.id
            };
            EmpService.add(data).success(function (data, status, headers, config) {
                if (data.is_inserted) {
                    $scope.SuccessFlag = true;
                    $scope.MSG = data.msg;
                    $scope.user = {};
                    $scope.user = angular.copy($scope.empType);
                    $scope.reloadData();
                    $scope.changeView('view');
                } else {
                    $scope.ErrorFlag = true;
                    $scope.MSG = data.msg;
                }
            }).error(function (data, status) {
                alert("Connection Error");
            });
        };

        $scope.delete = function (id) {
            if (confirm("Are you sure you want to delete this record?")) {
                EmpService.delete(id).success(function (data, status, headers, config) {
                    if (data.is_inserted) {
                        $scope.SuccessFlag = true;
                        $scope.MSG = data.msg;
                        $scope.user = {};
                        $scope.user = angular.copy($scope.empType);
                        $scope.reloadData();
                        $scope.changeView('view');
                    } else {
                        $scope.ErrorFlag = true;
                        $scope.MSG = data.msg;
                    }
                }).error(function (data, status) {
                    alert("Connection Error");
                });
            }
        }

        $scope.edit = function (id) {
            var userObj = angular.copy(EmpService.edit(id));
            userObj.availableOptions = angular.copy($scope.empType.availableOptions);
            userObj.EmpType = {id: userObj.EmpType1, name: userObj.user_type_name};
            $scope.user = userObj;
            $scope.changeView('add');
        }

        $scope.isCompleted = function (flag) {
            return !(flag == '0');
        }
    }
}]);
