angular.module('mHomeCtrl', []).controller('mHomeCtrl', function ($scope, $http, $location, $window, $rootScope, HomeServices) {
    $rootScope.adminpanel = false;
    $rootScope.userpanel = true;
    $scope.isLoginForm = true;

    if ($window.localStorage.getItem('cust_id') != null && $window.localStorage.getItem('cust_id') != '' && $window.localStorage.getItem('cust_id') != 'undefined') {
        $rootScope.isCustLogedIn = true;
        $rootScope.loggedInUser = "customer";
    }

    $scope.validatedFromDate = new Date();
    $scope.validatedToDate = new Date();
    $scope.validatedFromTime = new Date();
    $scope.validatedToTime = new Date();
    $scope.curTime = new Date();
    $scope.dateFormate = {
        format: 'dd-mm-yyyy', selectYears: true
    };

    HomeServices.get().success(function (data) {
        $scope.allData = data.records;
    });

    var userData = {id: $window.localStorage.getItem('cust_id')};
    HomeServices.getOrderHistory(userData).success(function (data) {
        $scope.orderHistory = data.records;
    });

    $scope.changeForm = function (view) {
        if (view == 'login') {
            $scope.isLoginForm = true;
        } else if (view == 'register') {
            $scope.isLoginForm = false;
        }
    }
    $scope.bookView = function (view) {
        if (view == 'book') {
            $scope.isOrderView = true;
            HomeServices.getFloor({}).success(function (data) {
                $scope.floorData = {
                    options: data.records
                }
            });
            $scope.SuccessFlag = false;
        } else if (view == 'order') {
            $scope.isOrderView = false;
            HomeServices.getOrderHistory(userData).success(function (data) {
                $scope.orderHistory = data.records;
            });
        }
    }

    $scope.isShow = function (view, size) {
        return (!view && size > 0)
    }
    /* Login operation starts*/
    $scope.register = function () {
        var data = {
            id: $scope.register.id,
            name: $scope.register.uname,
            email: $scope.register.email,
            password: $scope.register.passwords,
            mobileno: $scope.register.mobileno,
            dob: $scope.register.dob
        };
        HomeServices.add(data).success(function (data, status, headers, config) {
            if (data.is_inserted) {
                $scope.SuccessFlag = true;
                $scope.register = {};
                $scope.res_msg = data.msg;
            } else {
                $scope.ErrorFlag = true;
                $scope.MSG = data.msg;
            }
        }).error(function (data, status) {
            alert("Connection Error");
        });
    };

    $scope.getRooms = function (selected) {
        var data = {id: selected.id}
        HomeServices.getRoom(data).success(function (data) {
            $scope.roomData = {
                options: data.records
            }
        });
    }
    $scope.getAmount = function (selected) {
        $scope.book.amount = selected.amount;
    }
    /* Login operation starts*/
    $scope.login = function () {
        var data = {
            userName: $scope.login.username,
            password: $scope.login.password,
            type: 3
        }
        HomeServices.login(data).success(function (data, status, headers, config) {
            if (data.is_logged) {
                $window.localStorage.setItem('cust_type_id', data.user_type_id);
                $window.localStorage.setItem('cust_id', data.id);
                $window.localStorage.setItem('cust_uname', data.name);
                $rootScope.isCustLogedIn = true;
                $rootScope.loggedInUser = "customer";
                $('#close-modal').click();
            } else {
                $scope.loginFlag = true;
                $rootScope.isCustLogedIn = false;
                $scope.login_msg = "Please enter valid credential.";
            }
        }).error(function (data, status) {
            alert("Connection Error");
        });
    };

    /* Login operation starts*/
    $scope.booking = function () {
        var date_from = $scope.covertDateTime($scope.book.date_from, $scope.book.time_from);
        var date_to = $scope.covertDateTime($scope.book.date_to, $scope.book.time_to);
        var data = {
            floor: $scope.book.floor.id,
            room: $scope.book.room.id,
            booked_by: $window.localStorage.getItem('cust_id'),
            date_from: date_from,
            date_to: date_to,
            amount: $scope.book.amount
        }

        HomeServices.booking(data).success(function (data, status, headers, config) {
            if (data.is_inserted) {
                $scope.SuccessFlag = true;
                $scope.MSG = data.msg;
                $scope.book = {};
                $scope.bookView('order');
            } else {
                $scope.ErrorFlag = true;
                $scope.MSG = data.msg;
            }
        }).error(function (data, status) {
            alert("Connection Error");
        });
    };

    $scope.delete = function (id) {
        if (confirm("Are you sure you want to cancel this order?")) {
            HomeServices.delete(id).success(function (data, status, headers, config) {
                if (data.is_inserted) {
                    $scope.SuccessFlag = true;
                    $scope.MSG = data.msg;
                    $scope.book = {};
                    $scope.bookView('order');
                } else {
                    $scope.ErrorFlag = true;
                    $scope.MSG = data.msg;
                }
            }).error(function (data, status) {
                alert("Connection Error");
            });
        }
    }

    $scope.covertDateTime = function (date, time) {
        var hh = time.substr(0, time.indexOf(":"));
        hh = (hh.length == '1' ? '0' + hh : hh);
        hh = (time.indexOf("PM") != -1 ? (parseFloat(hh) + 12) : hh)
        var mm = time.substr(time.indexOf(":") + 1, time.indexOf(":") + 1);
        return date + " " + hh + ":" + mm + ":" + "00";
    }
    $scope.isCompleted = function (flag) {
        return (flag == '0');
    }
});
