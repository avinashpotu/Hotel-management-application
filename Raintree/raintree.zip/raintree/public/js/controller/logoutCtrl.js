angular.module('logoutCtrl', []).controller('logoutCtrl', function ($scope, $location, $window, $rootScope) {

    if ($window.localStorage.getItem('uid') != null) {
        $window.localStorage.removeItem('user_type_id');
        $window.localStorage.removeItem('uid');
        $window.localStorage.removeItem('uname');
        $location.path("/login");
    }
    if ($window.localStorage.getItem('empuid') != null) {
        $window.localStorage.removeItem('empuser_type_id');
        $window.localStorage.removeItem('empuid');
        $window.localStorage.removeItem('empuname');
        $location.path("/login");
    }
    console.log($window.localStorage.getItem('cust_id'));
    if ($window.localStorage.getItem('cust_id') != null) {
        $window.localStorage.removeItem('cust_type_id');
        $window.localStorage.removeItem('cust_id');
        $window.localStorage.removeItem('cust_uname');
        $rootScope.isCustLogedIn = false;
        $rootScope.loggedInUser = null;
        $location.path("/home");
    }
});
