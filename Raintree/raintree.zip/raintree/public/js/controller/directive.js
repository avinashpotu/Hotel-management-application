angular.module('pickerModule', []).directive('myPicker', function () {
    return {
        restrict: 'A',
        require: 'ngModel',
        link: function (scope, element, attrs, ngModelCtrl) {
            $(function () {
                element.datepicker({
                    dateFormat: 'dd-mm-yy',
                    onSelect: function (date) {
                        ngModelCtrl.$setViewValue(date);
                        scope.$digest();
                    }
                });
            });
        }
    }
});

angular.module('validFileModule', []).directive('validFile', function () {
    return {
        require: 'ngModel',
        link: function (scope, el, attrs, ngModel) {
            ngModel.$render = function () {
                ngModel.$setViewValue(el.val());
            };

            el.bind('change', function () {
                scope.$apply(function () {
                    ngModel.$render();
                });
            });
        }
    };
});

//
//angular.module('dataTableModule', []).directive('dataTable', function() {
//    return {
//        restrict: 'A',
//        require : 'ngModel',
//        link : function (scope, element, attrs, ngModelCtrl) {
//            $(function(){
//                element.DataTable({
//                    onSelect:function (date) {
//                        ngModelCtrl.$setViewValue(date);
//                        scope.$digest();
//                    }
//                });
//            });
//        }
//    }
//});