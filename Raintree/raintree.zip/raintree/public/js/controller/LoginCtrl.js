angular.module('loginCtrl', []).controller('LoginCtrl', function ($scope, $http, $location, $window, $rootScope) {

        $rootScope.adminpanel = true;
        $rootScope.userpanel = false;
        if ($window.localStorage.getItem('uid') != null && $window.localStorage.getItem('uid') != '' && $window.localStorage.getItem('uid') != 'undefined') {
            if ($window.localStorage.getItem('user_type_id') == "1") {
                $location.path("/mEmp");
            }
        } else if ($window.localStorage.getItem('empuid') != null && $window.localStorage.getItem('empuid') != '' && $window.localStorage.getItem('empuid') != 'undefined') {
            if ($window.localStorage.getItem('empuser_type_id') == "2") {
                $location.path("/eView");
            }
        }

        /* Login operation starts*/
        $scope.login = function () {
            var data = {
                userName: $scope.login.userName,
                password: $scope.login.password,
                type: $scope.login.staff
            }
            $http.post('/login', data).success(function (data, status, headers, config) {
                if (data.is_logged) {
                    $scope.LoginAlert = false;
                    if (data.user_type_id == 1) {
                        $window.localStorage.setItem('user_type_id', data.user_type_id);
                        $window.localStorage.setItem('uid', data.id);
                        $window.localStorage.setItem('uname', data.name);
                        $location.path("/mEmp");
                    } else if (data.user_type_id == 2) {
                        $window.localStorage.setItem('empuser_type_id', data.user_type_id);
                        $window.localStorage.setItem('empuid', data.id);
                        $window.localStorage.setItem('empuname', data.name);
                        $location.path("/eView");
                    }
                    $rootScope.loggedInUser = "staff";
                } else {
                    $scope.LoginAlert = true;
                }
            }).error(function (data, status) {
                alert("Connection Error");
            });
        };
    }
)
;
